public class Max_Min {
    public Integer max;
    public Integer min;
    public int arr[];
    public Integer n;

    public Integer Max() {
        for (int i = 0; i < n; i++) {
                if (arr[i] >= max)
                    max = arr[i];
            }
    return max;
    }
    public Integer Min() {
        for (int i = 0; i < n; i++) {
                if (arr[i] <= min)
                    min = arr[i];
            }
    return min;
    }

    public void initmax(Integer mx){ max = mx;}
    public void initmin(Integer mn){ min = mn;}
    public void initarr(int array[]){ arr = array;}
    public void initn(Integer num){ n = num;}
}