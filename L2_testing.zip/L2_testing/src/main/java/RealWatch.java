import java.io.OutputStream;
import java.io.PrintStream;

public class RealWatch {
    public char input;
    public String state;
    public String state1;
    public Integer m = 0, h = 0, D = 1, M = 1, Y = 2000;
    public int arr[]={m, h, D, M, Y};
    private Integer i;
    public boolean chime;

    public void Displayer() {

        switch (state) {
            case "NORMAL":{
                if(input == 'c') state = "UPDATE";
                if(input == 'b') state = "ALARM";
                if(input == 'a'){
                    state = "NORMAL";
                   if(state1 == "TIME")  state1 = "DATE";
                   else  state1 = "TIME";
                }
            }

            case "UPDATE": {
               if(input == 'd') state = "NORMAL";
               if(input == 'c') {
                   state  = "UPDATE";
                   i = 0;
                   while (i <= arr.length) {
                       if(input == 'b' && m<=60 && h<=24 && D<=31 && M<=12 && Y<=100)
                           arr[i]++;
                       if(input == 'a')
                           i++;
                       if(input == 'd')
                           state = "NORMAL";
                   }
                   if(i > arr.length && input == 'a')
                       state = "NORMAL";
               }
            }

            case "ALARM": {
                if(input == 'd')
                    state = "NORMAL";
                if(input == 'b') {
                    state = "ALARM";
                    if(input == 'a')
                        chime = true;
                    else
                        chime = false;
                }
            }
            Displaystate();
        }

        switch (state1) {
            case "TIME":
                DisplayTIME();
            case "DATE":
               DisplayDate();
          }
    }

    public String DisplayDate() {System.out.printf (Y+"-"+M+"-"+D); return null;}
    public String  DisplayTIME() {System.out.printf (h+":"+m); return null;}
    public String Displaystate() {System.out.printf ("State is: "+state); return null;}

    public void initinput(char in){ input = in;}
    public void initstate(String s){ state = s;}
    public void initstate1(String s1){ state1 = s1;}
    public void initarr(int array[]){ arr = array;}
    public void initi(Integer index){ i = index;}
    public void initchime(boolean ch){ chime = ch;}
    public void initm(Integer min){ m = min;}
    public void inith(Integer hr){ h = hr;}
    public void initD(Integer day){ D = day;}
    public void initM(Integer Month){ M = Month;}
    public void initY(Integer year){ Y = year;}


}


