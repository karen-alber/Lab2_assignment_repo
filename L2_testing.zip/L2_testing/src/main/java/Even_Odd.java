public class Even_Odd{
    public Integer num;
    private String res;

    public String Checker() {
     if (num % 2 == 0)
         res = "Number is Even";
     else
         res = "Number is Odd";
     return res;
 }

    public void initnum(Integer n){ num = n;}
    public void initres(String result){ res = result;}
}

