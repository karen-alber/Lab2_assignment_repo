import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Even_Odd_test {
    Even_Odd e_o1; //for 0
    Even_Odd e_o2; //for even positive value
    Even_Odd e_o3; //for odd positive value
    Even_Odd e_o4; //for even negative value
    Even_Odd e_o5; //for odd negative value
    Even_Odd e_o6; //for entering characters instead of numbers
    Even_Odd e_o7; //for entering float number

    @BeforeEach
    public void before(){
        e_o1 = new Even_Odd();
        e_o2 = new Even_Odd();
        e_o3 = new Even_Odd();
        e_o4 = new Even_Odd();
        e_o5 = new Even_Odd();
        e_o6 = new Even_Odd();
        e_o7 = new Even_Odd();
    }

    @Test
    public void Check(){
        String expectedresult1 = "Number is Even";
        String expectedresult2 = "Number is Even";
        String expectedresult3 = "Number is Odd";
        String expectedresult4 = "Number is Even";
        String expectedresult5 = "Number is Odd";

        e_o1.initnum(0);
        e_o2.initnum(12);
        e_o3.initnum(23);
        e_o4.initnum(-4);
        e_o5.initnum(-9);

        assertEquals("Number is Even", e_o1.Checker());
        assertEquals("Number is Even", e_o2.Checker());
        assertEquals("Number is Odd", e_o3.Checker());
        assertEquals("Number is Even", e_o4.Checker());
        assertEquals("Number is Odd", e_o5.Checker());

    }

    @AfterEach
    public void cleanup1(){ e_o1 = null; }
    public void cleanup2(){ e_o2 = null; }
    public void cleanup3(){ e_o3 = null; }
    public void cleanup4(){ e_o4 = null; }
    public void cleanup5(){ e_o5 = null; }

}