import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Array;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Max_Min_test {
    Max_Min mm;
    Max_Min my;

    @BeforeEach
    public void before() {
        mm = new Max_Min();
        my = new Max_Min();
    }

    @Test
    public void Check() {
        Integer expectedresult1_1 = 0;
        Integer expectedresult1_2 = 0;

        mm.initarr(new int[]{0});
        mm.initmin(0);
        mm.initmax(0);

        assertEquals(0, mm.min);
        assertEquals(0, mm.max);

        Integer expectedresult2_1 = 1;
        Integer expectedresult2_2 = 6;

        my.initarr(new int[]{1, 3, 6});
        my.initmin(1);
        my.initmax(6);


        assertEquals(1, my.min);
        assertEquals(6, my.max);
    }

    @AfterEach
    public void cleanup1() { mm = null; }
    public void cleanup2() { my = null; }

}