import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RealWatch_test {
    RealWatch rw;

    @BeforeEach
    public void before() {
        rw = new RealWatch();
    }

    @Test
    public void Check(){
        String expectedresult1 = "2000-01-01, 00:01, State is: NORMAL";

        //cdaacbaadcaaaaabdbad --> edge coverage and ADUP coverage included
        rw.initarr(new int[]{00,00, 01, 01, 2000});
        rw.initinput('c');
        //rw.initstate("UPDATE");
        rw.initinput('d');
        //rw.initstate("NORMAL");
        rw.initinput('a');
        //rw.initstate1("DATE");
        rw.initinput('a');
        //rw.initstate1("TIME");
        rw.initinput('c');
        //rw.initstate("UPDATE");
        rw.initinput('b');
        //rw.initm(00);
        rw.initinput('a');
        rw.initinput('a');
        rw.initinput('d');
        //rw.initstate("NORMAL");
        rw.initinput('c');
        //rw.initstate("UPDATE");
        rw.initinput('a');
        rw.initinput('a');
        rw.initinput('a');
        rw.initinput('a');
        rw.initinput('a');
        //rw.initstate("NORMAL");
        rw.initinput('b');
        rw.initinput('d');
        rw.initinput('b');
        //rw.initstate("ALARM");
        rw.initinput('a');
        //rw.initchime(true);
        rw.initinput('d');
        //rw.initstate("NORMAL");

        assertEquals("2000-01-01", rw.DisplayDate());
        assertEquals("00:01", rw.DisplayTIME());
        assertEquals("State is: NORMAL", rw.Displaystate());

    }

    @AfterEach
    public void cleanup1() { rw = null; }

}